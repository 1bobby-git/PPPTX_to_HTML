/* tslint:disable */
/* eslint-disable */

/**
 * Conversion result with HTML and metadata about unresolved elements.
 */
export class ConversionResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Canonical core conversion diagnostics JSON (compatibly named projection).
     */
    readonly diagnostics: string;
    /**
     * Canonical core conversion diagnostics JSON.
     */
    readonly diagnosticsJson: string;
    /**
     * The generated HTML string.
     */
    readonly html: string;
    /**
     * Number of slides processed.
     */
    readonly slideCount: number;
    /**
     * JSON array of unresolved elements (SmartArt, OLE, Math, custom geometry).
     *
     * Each element: `{ slideIndex, elementType, placeholderId, rawXml?, dataModel? }`
     */
    readonly unresolvedElements: string;
}

/**
 * Presentation metadata returned as a structured JS object.
 */
export class PresentationInfo {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly heightPx: number;
    readonly slideCount: number;
    readonly title: string | undefined;
    readonly widthPx: number;
}

/**
 * Convert PPTX bytes to an HTML string.
 */
export function convert(data: Uint8Array): string;

/**
 * Convert PPTX bytes to HTML with slide filtering (0-based indices).
 */
export function convert_slides(data: Uint8Array, slides: Uint32Array): string;

/**
 * Convert PPTX and return both HTML and metadata about unresolved elements.
 *
 * ```js
 * const result = convert_with_metadata(data);
 * const output = document.createElement('iframe');
 * output.setAttribute('sandbox', 'allow-scripts');
 * output.title = 'Converted slide output';
 * output.srcdoc = result.html;
 * document.body.appendChild(output);
 * const unresolved = JSON.parse(result.unresolvedElements);
 * ```
 */
export function convert_with_metadata(data: Uint8Array): ConversionResult;

/**
 * Convert PPTX with explicit options.
 *
 * ```js
 * const html = convert_with_options(
 *   data,
 *   false,
 *   true,
 *   new Uint32Array([1, 3, 5]),
 *   2.0,
 * );
 * ```
 *
 * `slide_indices` uses 1-based indexing. Pass an empty array to include all slides.
 */
export function convert_with_options(data: Uint8Array, embed_images: boolean, include_hidden: boolean, slide_indices: Uint32Array, scale: number): string;

/**
 * Convert PPTX with options and return both HTML and metadata.
 *
 * ```js
 * const result = convert_with_options_metadata(
 *   data,
 *   false,
 *   true,
 *   new Uint32Array([1, 3, 5]),
 *   2.0,
 * );
 * ```
 */
export function convert_with_options_metadata(data: Uint8Array, embed_images: boolean, include_hidden: boolean, slide_indices: Uint32Array, scale: number): ConversionResult;

/**
 * Get presentation metadata as JSON string.
 *
 * Kept for backward compatibility. Prefer `get_presentation_info()` for typed access.
 */
export function get_info(data: Uint8Array): string;

/**
 * Get presentation metadata as a typed object.
 *
 * ```js
 * const info = get_presentation_info(data);
 * console.log(info.slideCount, info.widthPx, info.heightPx, info.title);
 * ```
 */
export function get_presentation_info(data: Uint8Array): PresentationInfo;

/**
 * Get the number of slides in a PPTX file.
 */
export function get_slide_count(data: Uint8Array): number;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_conversionresult_free: (a: number, b: number) => void;
    readonly __wbg_presentationinfo_free: (a: number, b: number) => void;
    readonly conversionresult_diagnostics: (a: number) => [number, number];
    readonly conversionresult_html: (a: number) => [number, number];
    readonly conversionresult_slideCount: (a: number) => number;
    readonly conversionresult_unresolvedElements: (a: number) => [number, number];
    readonly convert: (a: number, b: number) => [number, number, number, number];
    readonly convert_slides: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly convert_with_metadata: (a: number, b: number) => [number, number, number];
    readonly convert_with_options: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly convert_with_options_metadata: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly get_info: (a: number, b: number) => [number, number, number, number];
    readonly get_presentation_info: (a: number, b: number) => [number, number, number];
    readonly get_slide_count: (a: number, b: number) => [number, number, number];
    readonly presentationinfo_heightPx: (a: number) => number;
    readonly presentationinfo_slideCount: (a: number) => number;
    readonly presentationinfo_title: (a: number) => [number, number];
    readonly presentationinfo_widthPx: (a: number) => number;
    readonly conversionresult_diagnosticsJson: (a: number) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
